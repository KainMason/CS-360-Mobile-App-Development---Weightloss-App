package com.example.weightloss;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

/**
 * SMSActivity
 * Screen for handling SMS permissions or logic.
 * Created by Kain Mason for CS 360 Project Two
 */
public class SMSActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);
    }
}
